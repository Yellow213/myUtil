package com.css.eshop.admin.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader 
{
	private String filePath="";
	private String [] fieldNames =null;
	private String [] fieldTypes = null;
	private String [] filedIsNull= null;
	private String sheetName;
	
	public static final String  FIELD_TYPE_STRING="string";//字符串类型
	public static final String  FIELD_TYPE_NUMBER="number";//数字类型
	public static final String  FIELD_TYPE_DATE="date"; //日期类型 
	
	private static final String FILE_TYPE_XLS="XLS";
	private static final String FILE_TYPE_XLSX="XLSX";
	
	private static final String isNull_TRUE="true";
	private static final String isNull_FALSE="false";
	
	private String currentFileType =this.FILE_TYPE_XLS;
	
//	private FileInputStream fIn=null; 
	 
	private Workbook wb;
	
	private List errorMsgList=null;
	
	public ExcelReader(String _filePath,String _sheetName,String [] _fieldNames,String[] _fieldTypes,String[] _filedIsNull)
	{
		this.filePath =_filePath; 
		this.sheetName =_sheetName;
		this.fieldNames =_fieldNames;
		this.fieldTypes = _fieldTypes;
		this.filedIsNull =_filedIsNull;
	
		errorMsgList= new ArrayList(); 
	}
	 
	/**********
	 * 
	 * 方法作用的描述 
	 * <br>	获得 表头的列名
	 * <br>
	 * 其他描述：使用方法、注意事项等（可选）。<br>
	 * 
	 * @param 参数名称  Excel 的 Sheet 对象  
	 *        参数描述
	 *        
	 * @return 返回的描述  
	 * 			返回 一个Map 对象，key= 列名 , value = 那一列的下标（第一列的下标为0）
	 * 
	 */
	private Map getColumnMap(Sheet sheet)
	{ 
		Row firstRow = sheet.getRow(0);
		Map cellNameMap = new HashMap();
		int maxCloumnNum = firstRow.getLastCellNum();
		for(int i=0;i<maxCloumnNum;i++)
		{
			String name = getStringFromCell(firstRow.getCell(i));
			cellNameMap.put(name.trim(), i);
		}
		
		return cellNameMap;
	}
	
	
	/******
	 * 
	 * 	获得Excel 某格的值
	 * @param cell
	 * @return
	 */
	private Object getValueFromCell(Cell cell)
	{ 
		if(cell!=null)
		{
			if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) 
			{
				if(cell.getStringCellValue()!=null)
					return cell.getStringCellValue().trim();
				else 
					return "";
			} 
			else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
			{
				if(HSSFDateUtil.isCellDateFormatted(cell))//取日期类型的值
				{
					return cell.getDateCellValue();
				}
				else
				{ 
					Double num=cell.getNumericCellValue();
					return  num;
				}
			}
			else if(cell.getCellType() ==HSSFCell.CELL_TYPE_FORMULA) //取计算公式的值
			{ 
				FormulaEvaluator evaluator = null; 
				if(currentFileType.equals(this.FILE_TYPE_XLS))
					evaluator =new HSSFFormulaEvaluator((HSSFWorkbook) wb);
				else if(currentFileType.equals(this.FILE_TYPE_XLSX))
					evaluator =new XSSFFormulaEvaluator((XSSFWorkbook) wb);
					 
				Double numValue = evaluator.evaluate(cell).getNumberValue();
				String strValue = evaluator.evaluate(cell).getStringValue();
				
				if(strValue==null) 
					return numValue;
				else
					return strValue; 
			}
			else
			{
//				System.out.println(">>>>>>>>>>>>>>>>>>>>> cell.getCellType()="+cell.getCellType());
				return "";
			}
		}
		else
			return "";
	}
	
	
	
	
	private String getExcelCellType(Cell cell)
	{
		if(cell!=null)
		{
			if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) 
			{
				return this.FIELD_TYPE_STRING;
			}
			else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
			{
				if(HSSFDateUtil.isCellDateFormatted(cell))//取日期类型的值
				{
					return this.FIELD_TYPE_DATE;
				}
				else
				{ 
					return this.FIELD_TYPE_NUMBER;
				}
			}
			else if(cell.getCellType() ==HSSFCell.CELL_TYPE_FORMULA) //取计算公式的值,
			{  
				FormulaEvaluator evaluator = null; 
				if(currentFileType.equals(this.FILE_TYPE_XLS))
					evaluator =new HSSFFormulaEvaluator((HSSFWorkbook) wb);
				else if(currentFileType.equals(this.FILE_TYPE_XLSX))
					evaluator =new XSSFFormulaEvaluator((XSSFWorkbook) wb);
				
				String strValue = evaluator.evaluate(cell).getStringValue();
				
				if(strValue==null) 
					return this.FIELD_TYPE_NUMBER;
				else
					return this.FIELD_TYPE_STRING;
			}
			else
				return this.FIELD_TYPE_STRING;
		}
		else
			return this.FIELD_TYPE_STRING;
	}
	
	
	
	
	/************
	 * 
	 * 方法作用的描述 
	 * <br>		获得那格Excel单元的数据
	 * <br>
	 * 其他描述：使用方法、注意事项等（可选）。<br>
	 * 
	 * @param 参数名称 HSSFCell cell
	 *        参数描述
	 */
	private String getStringFromCell(Cell cell)
	{ 
		if(cell!=null)
		{  
			if (cell.getCellType() == Cell.CELL_TYPE_STRING) 
			{
				if(cell.getStringCellValue()!=null)
					return cell.getStringCellValue().trim();
				else 
					return "";
			} 
			else if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC)
			{
				if(HSSFDateUtil.isCellDateFormatted(cell))//取日期类型的值
				{
					Date tempValue =cell.getDateCellValue();
					
					if(tempValue!=null)
					{
						 DateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd"); 
						 return   dt1.format(tempValue); 
					}
					else
						return "";
				}
				else
				{
					Double num=cell.getNumericCellValue();
					return  num.toString();
				}
			}
			else if(cell.getCellType() == Cell.CELL_TYPE_FORMULA) //取计算公式的值
			{
				FormulaEvaluator evaluator = null; 
				if(currentFileType.equals(this.FILE_TYPE_XLS))
					evaluator =new HSSFFormulaEvaluator((HSSFWorkbook) wb);
				else if(currentFileType.equals(this.FILE_TYPE_XLSX))
					evaluator =new XSSFFormulaEvaluator((XSSFWorkbook) wb);
				 
				Double numValue = evaluator.evaluate(cell).getNumberValue();
				String strValue = evaluator.evaluate(cell).getStringValue();
				
				if(strValue==null) 
					return numValue.toString();
				else
					return strValue; 
			}
			else
			{
//				System.out.println(">>>>>>>>>>>>>>>>>>>>> cell.getCellType()="+cell.getCellType());
				return "";
			}
		}
		else
			return "";
	}
	
	/********
	 * 根据列名获得对应行里的Excel单元
	 * @param cellNameMap
	 * @param cellName
	 * @param row
	 * @return
	 */
	private Cell getCellByName(Map cellNameMap,String cellName,Row row)
	{
		if(cellNameMap!=null&&cellName!=null)
		{
			Integer index =(Integer)cellNameMap.get(cellName);
			
			if(index!=null)
				return row.getCell(index);
			else
				return null;
		}
		else
			return null;
	} 
	
	private  List  readLineByRow(Map cellNameMap,Row row)
	{
		List valueList = new ArrayList();
		int m = 0;
		int n = 0;
		for(int i=0;i<this.fieldNames.length;i++)
		{
			Cell cell =  this.getCellByName(cellNameMap, fieldNames[i].trim(), row);
			
			Object cellValue=getValueFromCell(cell);
			
			if(filedIsNull[i].equals(isNull_FALSE) 
					&& ( cellValue ==null || cellValue.equals("")) 
			)
			{
				this.errorMsgList.add("第"+row.getRowNum()+"行的  \""+fieldNames[i]+"\" 字段不能为空!" );
				n++;
			}
			else
			{
				if(this.fieldTypes!=null && fieldTypes[i]!=null && (cellValue !=null&& !cellValue.equals("")))
			{
				if(!fieldTypes[i].equals(FIELD_TYPE_STRING) &&!fieldTypes[i].equals(getExcelCellType(cell)))
				{
					StringBuffer errorMsg = new StringBuffer("第"+row.getRowNum()+"行的  \""+fieldNames[i]+"\" 字段不是" );
					
					if(fieldTypes[i].equals(FIELD_TYPE_NUMBER))
						errorMsg.append("数字类型");
					else if(fieldTypes[i].equals(this.FIELD_TYPE_DATE))
						errorMsg.append("日期类型"); 
					
					this.errorMsgList.add(errorMsg);
				}
			}
//			String fieldValue = this.getStringFromCell(cell);
		  
			if(fieldTypes[i].equals(FIELD_TYPE_STRING) && FIELD_TYPE_NUMBER.equals(getExcelCellType(cell)))
			{
					String fieldValue = cellValue.toString();
				if(!fieldValue.equals("") && fieldValue.indexOf(".")!=-1 )
					fieldValue=fieldValue.substring(0, fieldValue.indexOf("."));
			
				valueList.add(fieldValue);
				System.out.print("{"+fieldValue+"}  "); 
			}
			else
			{
					Object fieldValue = cellValue; 
			valueList.add(fieldValue);
				System.out.print("{"+fieldValue+"}  "); 
			}
			
			}//end if(filedIsNull[i].equals(isNull_FALSE) && cellValue ==null)
			
			//L36346_1 kong.xiang.hui start
			if(cellValue ==null || cellValue.equals("")){
				m++;
				if(m==this.fieldNames.length){//如果整行空白
					for(int k = 0;k<n;k++){
						this.errorMsgList.remove(this.errorMsgList.size() - 1);//移除因为空白行而加入的错误信息，不处理空白行
					}
				}
			}
			
//			System.out.print( "["+cell.getCellType()   +"]  ");
		}
		System.out.println("");
		return valueList;
	}
	
	 
	public List<List<String>> read()
	{
		if(errorMsgList==null)
			errorMsgList =new ArrayList();
		else
			errorMsgList.clear();
		
		List allDataList =new ArrayList();
		List valueList = new ArrayList();//L36346_1 kong.xiang.hui
		//产生工作簿对象
		FileInputStream fIn=null;
		try 
		{
			fIn=new FileInputStream(filePath);
			if(filePath.lastIndexOf(".xlsx")!=-1)
			{
				wb= new XSSFWorkbook(fIn);
				currentFileType =this.FILE_TYPE_XLSX; 
			}
			else
			{
				wb= new HSSFWorkbook(fIn); 
			}
			
			Sheet readSheet= wb.getSheet(sheetName); 
			
			if(readSheet==null)
			{
				errorMsgList.add("Excel 文件的Sheet 名称不正确，应该改为"+sheetName);
			}
			else
			{
				Map cellNameMap =this.getColumnMap(readSheet);//获得表头字段对应的下标

				int maxNum = readSheet.getLastRowNum();
				for(int i=1;i<=maxNum;i++)
				{
					Row row    = readSheet.getRow(i);
					//L36346_1 kong.xiang.hui start
					int k = 0;
					if(row!=null){
						valueList = this.readLineByRow(cellNameMap, row);
						if(valueList.size() > 0){
							for(int m = 0; m < valueList.size(); m ++){
								if("".equals(valueList.get(m))){
									k ++;
								}
							}
							if(k != valueList.size()){
								allDataList.add(valueList);
							}
						}
					}
					//L36346_1 kong.xiang.hui end
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			errorMsgList.add(e.getMessage());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(fIn!=null)
			{
				try {
					fIn.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} 
		return allDataList;
	}

	//L46727_1_2 guo.jing.bin start 修改了一个地方， 修复读取大数时会变成科学记数法的bug
	public List<List<String>> read2()
	{
		if(errorMsgList==null)
			errorMsgList =new ArrayList();
		else
			errorMsgList.clear();

		List allDataList =new ArrayList();
		List valueList = new ArrayList();//L36346_1 kong.xiang.hui
		//产生工作簿对象
		FileInputStream fIn=null;
		try
		{
			fIn=new FileInputStream(filePath);
			if(filePath.lastIndexOf(".xlsx")!=-1)
			{
				wb= new XSSFWorkbook(fIn);
				currentFileType =this.FILE_TYPE_XLSX;
			}
			else
			{
				wb= new HSSFWorkbook(fIn);
			}

			Sheet readSheet= wb.getSheet(sheetName);

			if(readSheet==null)
			{
				errorMsgList.add("Excel 文件的Sheet 名称不正确，应该改为"+sheetName);
			}
			else
			{
				Map cellNameMap =this.getColumnMap(readSheet);//获得表头字段对应的下标

				int maxNum = readSheet.getLastRowNum();
				for(int i=1;i<=maxNum;i++)
				{
					Row row    = readSheet.getRow(i);
					//L36346_1 kong.xiang.hui start
					int k = 0;
					if(row!=null){
						valueList = this.readLineByRow2(cellNameMap, row);
						if(valueList.size() > 0){
							for(int m = 0; m < valueList.size(); m ++){
								if("".equals(valueList.get(m))){
									k ++;
								}
							}
							if(k != valueList.size()){
								allDataList.add(valueList);
							}
						}
					}
					//L36346_1 kong.xiang.hui end
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			errorMsgList.add(e.getMessage());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(fIn!=null)
			{
				try {
					fIn.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return allDataList;
	}

	private  List  readLineByRow2(Map cellNameMap,Row row)
	{
		List valueList = new ArrayList();
		//L36346_1 kong.xiang.hui start
		int m = 0;
		int n = 0;
		//L36346_1 kong.xiang.hui end
		for(int i=0;i<this.fieldNames.length;i++)
		{
			Cell cell =  this.getCellByName(cellNameMap, fieldNames[i].trim(), row);

			Object cellValue=getValueFromCell2(cell);

			if(filedIsNull[i].equals(isNull_FALSE)
					&& ( cellValue ==null || cellValue.equals(""))
					)
			{
				this.errorMsgList.add("第"+row.getRowNum()+"行的  \""+fieldNames[i]+"\" 字段不能为空!" );
				n++;
			}
			else
			{
				if(this.fieldTypes!=null && fieldTypes[i]!=null && (cellValue !=null&& !cellValue.equals("")))
				{
					if(!fieldTypes[i].equals(FIELD_TYPE_STRING) &&!fieldTypes[i].equals(getExcelCellType(cell)))
					{
						StringBuffer errorMsg = new StringBuffer("第"+row.getRowNum()+"行的  \""+fieldNames[i]+"\" 字段不是" );

						if(fieldTypes[i].equals(FIELD_TYPE_NUMBER))
							errorMsg.append("数字类型");
						else if(fieldTypes[i].equals(this.FIELD_TYPE_DATE))
							errorMsg.append("日期类型");

						this.errorMsgList.add(errorMsg);
					}
				}
				if(fieldTypes[i].equals(FIELD_TYPE_STRING) && FIELD_TYPE_NUMBER.equals(getExcelCellType(cell)))
				{
					String fieldValue = cellValue.toString();
					if(!fieldValue.equals("") && fieldValue.indexOf(".")!=-1 )
						fieldValue=fieldValue.substring(0, fieldValue.indexOf("."));

					valueList.add(fieldValue);
					System.out.print("{"+fieldValue+"}  ");
				}
				else
				{
					Object fieldValue = cellValue;
					valueList.add(fieldValue);
					System.out.print("{"+fieldValue+"}  ");
				}

			}//end if(filedIsNull[i].equals(isNull_FALSE) && cellValue ==null)

			if(cellValue ==null || cellValue.equals("")){
				m++;
				if(m==this.fieldNames.length){//如果整行空白
					for(int k = 0;k<n;k++){
						this.errorMsgList.remove(this.errorMsgList.size() - 1);//移除因为空白行而加入的错误信息，不处理空白行
					}
				}
			}
		}
		System.out.println("");
		return valueList;
	}

	/******
	 *
	 * 	获得Excel 某格的值,修复获取大数时会显示科学计数法的问题
	 * @param cell
	 * @return
	 */
	private Object getValueFromCell2(Cell cell)
	{
		if(cell!=null)
		{
			if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING)
			{
				if(cell.getStringCellValue()!=null)
					return cell.getStringCellValue().trim();
				else
					return "";
			}
			else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
			{
				if(HSSFDateUtil.isCellDateFormatted(cell))//取日期类型的值
				{
					return cell.getDateCellValue();
				}
				else
				{
					Double num=cell.getNumericCellValue();
					//fix bug 读取大数时会变成科学记数法
					return  new DecimalFormat("0.00").format(num);
				}
			}
			else if(cell.getCellType() ==HSSFCell.CELL_TYPE_FORMULA) //取计算公式的值
			{
				FormulaEvaluator evaluator = null;
				if(currentFileType.equals(this.FILE_TYPE_XLS))
					evaluator =new HSSFFormulaEvaluator((HSSFWorkbook) wb);
				else if(currentFileType.equals(this.FILE_TYPE_XLSX))
					evaluator =new XSSFFormulaEvaluator((XSSFWorkbook) wb);

				Double numValue = evaluator.evaluate(cell).getNumberValue();
				String strValue = evaluator.evaluate(cell).getStringValue();

				if(strValue==null)
					return numValue;
				else
					return strValue;
			}
			else
			{
				return "";
			}
		}
		else
			return "";
	}

	public List getErrorMsgList() {
		return errorMsgList;
	}

	public void setErrorMsgList(List errorMsgList) {
		this.errorMsgList = errorMsgList;
	}

	public static void main(String [] args)
	{
//		String filePath ="c:\\20111102物料发造单.xlsx";
//		String sheetName="物料发造单";  
//		String [] filedNames ={ "供应商"
//				,"物料代号" 
//				,"每件含税价(元)" 
//				,"小计(元)"
//				,"预计到货时间"
//				,"结账金额" 
//				};
//		
//		String [] filedType={FIELD_TYPE_STRING
//				,FIELD_TYPE_STRING
//				,FIELD_TYPE_NUMBER
//				,FIELD_TYPE_NUMBER
//				,FIELD_TYPE_DATE
//				,FIELD_TYPE_NUMBER
//				,FIELD_TYPE_STRING
//		};
		
		String filePath ="D:\\2019年9月6日关于CNeshop9月17日-10月10日 Wedding Special 活动\\worktest.xlsx";
		String sheetName="定价黄铂金";  
		String [] filedNames ={ "EShop 款号"
				,"用途" 
				,"货品类别" 
				,"类型" 
				};
		
		String [] filedType={FIELD_TYPE_STRING
				,FIELD_TYPE_STRING
				,FIELD_TYPE_STRING
				,FIELD_TYPE_STRING
		};

		String [] filedIsNull ={ isNull_TRUE
				,isNull_TRUE 
				,isNull_TRUE 
				,isNull_TRUE
				};

		//ExcelReader util = new ExcelReader(filePath,sheetName,filedNames,filedType,filedIsNull);
		ExcelReader util = new ExcelReader(filePath,sheetName,filedNames,filedType,filedIsNull);
		 
		List list = util.read(); 
		List msgList =util.getErrorMsgList();//错误的
		System.out.println("list.size : "+list.size());
		for(int i=0;i<list.size();i++)
		{
			//System.out.println(list.get(i));
			
			List datas=(List) list.get(i);
			String thirdPartyid=(String)datas.get(0);
			System.out.println("thirdPartyid:"+thirdPartyid+",开票日期:"+(String)datas.get(1)+",发票代码:"+(String)datas.get(2)
			+ ",发票号码:"+(String)datas.get(3));
			
			
		}
		
	}
	
}
