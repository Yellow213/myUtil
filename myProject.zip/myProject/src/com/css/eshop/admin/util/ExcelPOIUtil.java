package com.css.eshop.admin.util;
import org.apache.poi.hssf.usermodel.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//

public class ExcelPOIUtil {


    /**
     * @param args

     * @throws IOException

     * java xuzhe.ExcelPOI

     */

    @SuppressWarnings("deprecation")

    public static void main(String[] args)throws IOException {

       // TODO Auto-generatedmethod stub
    	//ExcelPOIUtil.POICreateExcel();
    	ExcelPOIUtil.POIReadExcel();

    }

    public static void POICreateExcel() throws IOException

/*��1���ж��ļ���׺����xls������xlsx

��2�������xls��ʹ��HSSFWorkbook�������xlsx��ʹ��XSSFWorkbook*/
    {
       HSSFWorkbook wb = new HSSFWorkbook();
       HSSFSheet sheet = wb.createSheet("new sheet");
       //0��
       HSSFRow row = sheet.createRow((short)0);
       //1��
       row.createCell((short)1).setCellValue("HelloWorld");
       FileOutputStream fileOut = new FileOutputStream("D:\\2019��9��6�չ���CNeshop9��17��-10��10�� Wedding Special �\\workbook.xls");
       wb.write(fileOut);
       fileOut.close();
    }

    private static HSSFWorkbook readFile(String filename) throws IOException {
       return new HSSFWorkbook(new FileInputStream(filename));
    }


    public static void POIReadExcel() throws IOException
     {
        String fileName = "D:\\2019��9��6�չ���CNeshop9��17��-10��10�� Wedding Special �\\work.xls";
        HSSFWorkbook wb =ExcelPOIUtil.readFile(fileName);
           System.out.println(fileName);
           for (int k = 0; k < wb.getNumberOfSheets(); k++)
           {
              HSSFSheet sheet = wb.getSheetAt(k);
              int rows = sheet.getPhysicalNumberOfRows();
              System.out.println("Sheet" + k +" \"" +wb.getSheetName(k) + "\" has" + rows
                     + "row(s).");

              for (int r = 0; r < rows; r++)
              {
                  HSSFRow row = sheet.getRow(r);
                  if (row ==null) {
                     continue;
                  }
                  int cells = row.getPhysicalNumberOfCells();
                  System.out.println("\nROW" + row.getRowNum() +" has " + cells
                         + "cell(s).");
                  for (int c = 0; c < cells; c++)
                  {
                     HSSFCell cell = row.getCell(c);
                     String value = null;
                     switch (cell.getCellType())
                     {
                         case HSSFCell.CELL_TYPE_FORMULA:
                            value = "FORMULA value=" +cell.getCellFormula();
                            break;
                         case HSSFCell.CELL_TYPE_NUMERIC:
                             value= "NUMERIC value=" + cell.getNumericCellValue();
                            break;
                         case HSSFCell.CELL_TYPE_STRING:
                            value = "STRING value=" +cell.getStringCellValue();
                            break;
                         default:
                     }
                     System.out.println("CELL col=" + cell.getColumnIndex()+" VALUE="

                            + value);
                  }
              }
           }
     }
}

