/*
 * Log			changed by 	 Date			Desc
 * L20827_1    shen.yuan     2011-06-09     invoice  manager
 * L21778_1    li.pei.jie    2011-09-26     add weight and weight_unit
 * L40005_1    li.pei.jie	 2016-05-05		鐢靛瓙鍙戠エ椤圭洰
 * L46242_1    zhong.hai.hao 2017-07-26     楹荤儲灏嗛噾瀹濆拰鎽嗕欢鐨勭◣鏀剁紪鐮佷慨鏀�
 * L45278_2    CailenNg      2018-03-05     change get the electronic invoice comod code by json
 * L49603_1    zhou.ren.kuan 2018-04-19		绯荤粺浠ユ垚鏈紙鍚◣锛�/1.16*0.16璁＄畻澧炲�肩◣
*/
package com.css.eshop.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InvcDetail implements java.io.Serializable {
	private String hdr_id;
	private String seq_nbr;
	private String item_nbr;
	private String product_desc;
	private String usage_desc;
	private String qty_unit;
	private int qty;
	private double amt_wo_tax;
	private double amt;
	private double tax_rate;
	private double tax_amt;
	private double disc_amt;
	private double disc_tax_amt;
	private double disc_rte;
	private String order_key;
	private int order_line_nbr;
	
	
	
	public String getOrder_key() {
		return order_key;
	}
	public void setOrder_key(String order_key) {
		this.order_key = order_key;
	}
	public int getOrder_line_nbr() {
		return order_line_nbr;
	}
	public void setOrder_line_nbr(int order_line_nbr) {
		this.order_line_nbr = order_line_nbr;
	}
	public String getHdr_id() {
		return hdr_id;
	}
	public void setHdr_id(String hdr_id) {
		this.hdr_id = hdr_id;
	}
	public String getSeq_nbr() {
		return seq_nbr;
	}
	public void setSeq_nbr(String seq_nbr) {
		this.seq_nbr = seq_nbr;
	}
	public String getItem_nbr() {
		return item_nbr;
	}
	public void setItem_nbr(String item_nbr) {
		this.item_nbr = item_nbr;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public String getUsage_desc() {
		return usage_desc;
	}
	public void setUsage_desc(String usage_desc) {
		this.usage_desc = usage_desc;
	}
	public String getQty_unit() {
		return qty_unit;
	}
	public void setQty_unit(String qty_unit) {
		this.qty_unit = qty_unit;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getAmt_wo_tax() {
		return amt_wo_tax;
	}
	public void setAmt_wo_tax(double amt_wo_tax) {
		this.amt_wo_tax = amt_wo_tax;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}
	public double getTax_rate() {
		return tax_rate;
	}
	public void setTax_rate(double tax_rate) {
		this.tax_rate = tax_rate;
	}
	public double getTax_amt() {
		return tax_amt;
	}
	public void setTax_amt(double tax_amt) {
		this.tax_amt = tax_amt;
	}
	public double getDisc_amt() {
		return disc_amt;
	}
	public void setDisc_amt(double disc_amt) {
		this.disc_amt = disc_amt;
	}
	public double getDisc_tax_amt() {
		return disc_tax_amt;
	}
	public void setDisc_tax_amt(double disc_tax_amt) {
		this.disc_tax_amt = disc_tax_amt;
	}
	public double getDisc_rte() {
		return disc_rte;
	}
	public void setDisc_rte(double disc_rte) {
		this.disc_rte = disc_rte;
	}
	
	//L21778_1 start
	private float weight;
	
	private String weight_unit;

	public float getWeight() {
		return weight;
	}
	
	public void setWeight(float weight) {
		this.weight = weight;
	}
	
	public String getWeight_unit() {
		return weight_unit;
	}
	
	public void setWeight_unit(String weight_unit) {
		this.weight_unit = weight_unit;
	}
	//L21778_1 end
	
	//L40005_1 li.pei.jie start
	public double getNoTaxAmtByAmt(){
		BigDecimal amtBd=new BigDecimal(this.amt);
//		BigDecimal taxBd=new BigDecimal(LoadStaticReferenceTables.getSystemParm("VAT_RTE"));//L49603_1 zhou.ren.kuan
		BigDecimal taxBd=new BigDecimal(taxPct+"");
		BigDecimal noTaxAmtBd=amtBd.divide(taxBd,2,RoundingMode.HALF_UP);
		return noTaxAmtBd.doubleValue();
	}
	
	public double getTaxAmtByAmt(){
		BigDecimal amtBd=new BigDecimal(this.amt);
		BigDecimal noTaxAmtBd=new BigDecimal(getNoTaxAmtByAmt());
		return amtBd.subtract(noTaxAmtBd).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	
	public double getTaxRate(){
//		BigDecimal vatRte=new BigDecimal(LoadStaticReferenceTables.getSystemParm("VAT_RTE"));//L49603_1 zhou.ren.kuan
		BigDecimal vatRte=new BigDecimal(taxPct+"");
		BigDecimal one=new BigDecimal(1);
		return vatRte.subtract(one).doubleValue();
	}
	
	public String getUnit(){
		if(weight_unit!=null && !"".equals(weight_unit.trim())){
			return weight_unit;
		}
		return qty_unit;
	}
	
	public float getQtyByUnit(){
		if(weight_unit!=null && !"".equals(weight_unit.trim())){
			return weight;
		}
		return qty;
	}
	
	public double getUnitPrice(){
		double noTanAmt=getNoTaxAmtByAmt();
		BigDecimal noTaxAmtBd=new BigDecimal(noTanAmt).abs();
		if(weight_unit!=null && !"".equals(weight_unit.trim())){
			BigDecimal unitBd=new BigDecimal(Float.toString(weight)).abs();
			BigDecimal unitPriceBd=noTaxAmtBd.divide(unitBd,6,RoundingMode.HALF_UP);
			return unitPriceBd.doubleValue();
		}
		return noTaxAmtBd.doubleValue();
	}
	
	private boolean selectInd;

	private String subOrderRefNbr;
	
	private String modelPlusNbr;
	
	private String identifier;
	
	private String usage;

	private String invcType;

	private String prodType;

	private String orderLineStatCde;
	
	private double sysPrice;
	
	private double price; 
	
	public String getProdType() {
		return prodType;
	}
	
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	
	public String getOrderLineStatCde() {
		return orderLineStatCde;
	}
	
	public void setOrderLineStatCde(String orderLineStatCde) {
		this.orderLineStatCde = orderLineStatCde;
	}
	
	public String getInvcType() {
		return invcType;
	}
	
	public void setInvcType(String invcType) {
		this.invcType = invcType;
	}
	
	public String getUsage() {
		return usage;
	}
	
	public void setUsage(String usage) {
		this.usage = usage;
	}
	
	public boolean isSelectInd() {
		return selectInd;
	}
	
	public void setSelectInd(boolean selectInd) {
		this.selectInd = selectInd;
	}
	
	public String getSubOrderRefNbr() {
		return subOrderRefNbr;
	}
	
	public void setSubOrderRefNbr(String subOrderRefNbr) {
		this.subOrderRefNbr = subOrderRefNbr;
	}
	
	public String getModelPlusNbr() {
		return modelPlusNbr;
	}
	
	public void setModelPlusNbr(String modelPlusNbr) {
		this.modelPlusNbr = modelPlusNbr;
	}
	
	public String getIdentifier() {
		return identifier;
	}
	
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	
	public String getOrderLineStatCdeDesc() {
		String temp="";
		try {  		
			if ( orderLineStatCde != null) {
			//	temp= LoadStaticReferenceTables.getStaticReference("ORDSTATUS", orderLineStatCde).getDescription(Utils.getCurrentLocale());
			}
		} catch (Exception e) {
		}
		
		return temp;
	}
	
	public double getSysPrice() {
		return sysPrice;
	}
	
	public void setSysPrice(double sysPrice) {
		this.sysPrice = sysPrice;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getProdTypeDesc() {
		String temp="";
		try {
			if ( prodType != null) {
			//	temp= LoadStaticReferenceTables.getStaticReference("T1", prodType).getDescription(Utils.getCurrentLocale());
			}
		} catch (Exception e) {
		}
		return temp;
	}
	//L40005_1 li.pei.jie end
	
	//L46242_1 zhong.hai.hao start
	private Date orderDate;
	
	private Date GI_elec_comod_day;
	
	private Date GB_elec_comod_day;

	public Date getOrderDate() {
		return orderDate;
	}
	
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	public Date getGI_elec_comod_day() {
		return GI_elec_comod_day;
	}
	
	public void setGI_elec_comod_day(Date gI_elec_comod_day) {
		GI_elec_comod_day = gI_elec_comod_day;
	}
	
	public Date getGB_elec_comod_day() {
		return GB_elec_comod_day;
	}
	
	public void setGB_elec_comod_day(Date gB_elec_comod_day) {
		GB_elec_comod_day = gB_elec_comod_day;
	}
	
	private String elec_invc_comod_cde;
	
	public void setElec_invc_comod_cde(String elec_invc_comod_cde) {
		this.elec_invc_comod_cde = elec_invc_comod_cde;
	}
	
	public String getElec_invc_comod_cde(){
			return elec_invc_comod_cde;
	}
	//L46242_1 zhong.hai.hao end
	
	//L49603_1 zhou.ren.kuan start
	private float taxPct;

	public float getTaxPct() {
		return taxPct;
	}
	public void setTaxPct(float taxPct) {
		this.taxPct = taxPct;
	}
	//L49603_1 zhou.ren.kuan end
}
