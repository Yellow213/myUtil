/*
 * Log			changed by 	 Date			Desc
 * L20827_1    shen.yuan     2011-06-09     invoice  manager
 * L40005_1    li.pei.jie	 2016-05-05		电子发票项目
 * L40005_4	   li.pei.jie    2016-08-01		电子发票项目优化
 * L40005_8	   li.pei.jie	 2016-12-06		优化百望报表,信息写入备用字段
 * L46242_1    zhong.hai.hao 2017-07-26     麻烦将金宝和摆件的税收编码修�?
 * L49603_1    zhou.ren.kuan 2018-04-19		系统以成本（含税�?/1.16*0.16计算增�?�税
*/
package com.css.eshop.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class InvcHdr implements java.io.Serializable {
	private String id;
	private String order_key;
	private Date   recpt_dte;
	private String cust_key;
	private String cust_name;
	private String css_tax_id;
	private String css_address;
	private String css_bank_ac;
	private String invc_type;
	private String remark;
	private String stat_cde;
	private String wh_invc_id;
	private String wh_invc_nbr;
	private Date   invc_dte;
	private ArrayList<InvcDetail> InvcDetailList;
	private String create_user;
	private Date   create_dte;
	private Date   update_dte;
	private Time   recpt_time;
	private Time   invc_time;
	private Time   create_time;
	private Time   update_time;
	private String and_red_ind;
	private String and_red_id;
	
	
	
	public String getAnd_red_id() {
		return and_red_id;
	}
	public void setAnd_red_id(String and_red_id) {
		this.and_red_id = and_red_id;
	}
	public String getAnd_red_ind() {
		return and_red_ind;
	}
	public void setAnd_red_ind(String and_red_ind) {
		this.and_red_ind = and_red_ind;
	}
	public Time getRecpt_time() {
		return recpt_time;
	}
	public void setRecpt_time(Time recpt_time) {
		this.recpt_time = recpt_time;
	}
	public Time getInvc_time() {
		return invc_time;
	}
	public void setInvc_time(Time invc_time) {
		this.invc_time = invc_time;
	}
	public Time getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Time create_time) {
		this.create_time = create_time;
	}
	public Time getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Time update_time) {
		this.update_time = update_time;
	}
	public String getCreate_user() {
		return create_user;
	}
	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}
	public Date getCreate_dte() {
		return create_dte;
	}
	public void setCreate_dte(Date create_dte) {
		this.create_dte = create_dte;
	}
	public Date getUpdate_dte() {
		return update_dte;
	}
	public void setUpdate_dte(Date update_dte) {
		this.update_dte = update_dte;
	}
	public ArrayList<InvcDetail> getInvcDetailList() {
		return InvcDetailList;
	}
	public void setInvcDetailList(ArrayList<InvcDetail> invcDetailList) {
		InvcDetailList = invcDetailList;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOrder_key() {
		return order_key;
	}
	public void setOrder_key(String order_key) {
		this.order_key = order_key;
	}
	public Date getRecpt_dte() {
		return recpt_dte;
	}
	public void setRecpt_dte(Date recpt_dte) {
		this.recpt_dte = recpt_dte;
	}
	public String getCust_key() {
		return cust_key;
	}
	public void setCust_key(String cust_key) {
		this.cust_key = cust_key;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCss_tax_id() {
		return css_tax_id;
	}
	public void setCss_tax_id(String css_tax_id) {
		this.css_tax_id = css_tax_id;
	}
	public String getCss_address() {
		return css_address;
	}
	public void setCss_address(String css_address) {
		this.css_address = css_address;
	}
	public String getCss_bank_ac() {
		return css_bank_ac;
	}
	public void setCss_bank_ac(String css_bank_ac) {
		this.css_bank_ac = css_bank_ac;
	}
	public String getInvc_type() {
		return invc_type;
	}
	public void setInvc_type(String invc_type) {
		this.invc_type = invc_type;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStat_cde() {
		return stat_cde;
	}
	public void setStat_cde(String stat_cde) {
		this.stat_cde = stat_cde;
	}
	public String getWh_invc_id() {
		return wh_invc_id;
	}
	public void setWh_invc_id(String wh_invc_id) {
		this.wh_invc_id = wh_invc_id;
	}
	public String getWh_invc_nbr() {
		return wh_invc_nbr;
	}
	public void setWh_invc_nbr(String wh_invc_nbr) {
		this.wh_invc_nbr = wh_invc_nbr;
	}
	public Date getInvc_dte() {
		return invc_dte;
	}
	public void setInvc_dte(Date invc_dte) {
		this.invc_dte = invc_dte;
	}
	
	public String getState_cde_desc(){
		String temp="";
		try {  		
			if ( stat_cde != null) {
			//	temp= LoadStaticReferenceTables.getStaticReference("INVCSTATECDE", stat_cde).getDescription(Utils.getCurrentLocale());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}

	//L27394_2 li.pei.jie start
	private String mach_id;

	public String getMach_id() {
		return mach_id;
	}
	
	public void setMach_id(String mach_id) {
		this.mach_id = mach_id;
	}
	//L27394_2 li.pei.jie end
	
	
	//L40005_1 li.pei.jie start
	public double getTotalAmt(){
		double totoalAmt=0.0d;
		if(InvcDetailList!=null && InvcDetailList.size()>0){
			for(InvcDetail invcDetail:InvcDetailList){
				//L40005_4 li.pei.jie start
				if(invcDetail.isSelectInd()){				
					totoalAmt+=invcDetail.getAmt();
				}
				//L40005_4 li.pei.jie end
			}
		}
		return new BigDecimal(totoalAmt).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	
	public double getTotalNoTaxAmtByAmt(){
		double totoalNoTaxAmt=0.0d;
		if(InvcDetailList!=null && InvcDetailList.size()>0){
			for(InvcDetail invcDetail:InvcDetailList){
				//L40005_4 li.pei.jie start
				if(invcDetail.isSelectInd()){	
					totoalNoTaxAmt+=invcDetail.getNoTaxAmtByAmt();
				}
				//L40005_4 li.pei.jie end
			}
		}
		return new BigDecimal(totoalNoTaxAmt).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	
	public double getTotalTaxAmtByAmt(){
		double totoalTaxAmt=0.0d;
		if(InvcDetailList!=null && InvcDetailList.size()>0){
			for(InvcDetail invcDetail:InvcDetailList){
				//L40005_4 li.pei.jie start
				if(invcDetail.isSelectInd()){	
					totoalTaxAmt+=invcDetail.getTaxAmtByAmt();
				}
				//L40005_4 li.pei.jie end
			}
		}
		return new BigDecimal(totoalTaxAmt).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	
	private String custTel;
	
	private String pdfUrl;

	private String origWhInvcId;
	
	private String origWhInvcNbr;

	public String getCustTel() {
		return custTel;
	}
	
	public void setCustTel(String custTel) {
		this.custTel = custTel;
	}
	
	public String getOrigWhInvcId() {
		if(origWhInvcId==null){
			origWhInvcId="";
		}
		return origWhInvcId;
	}
	
	public void setOrigWhInvcId(String origWhInvcId) {
		this.origWhInvcId = origWhInvcId;
	}
	
	public String getOrigWhInvcNbr() {
		if(origWhInvcNbr==null){
			origWhInvcNbr="";
		}
		return origWhInvcNbr;
	}
	
	public void setOrigWhInvcNbr(String origWhInvcNbr) {
		this.origWhInvcNbr = origWhInvcNbr;
	}
	
	private String taxNoteMethd;

	public String getTaxNoteMethd() {
		return taxNoteMethd;
	}
	
	public void setTaxNoteMethd(String taxNoteMethd) {
		this.taxNoteMethd = taxNoteMethd;
	}

	private boolean hasDataInd;

	public boolean isHasDataInd() {
		return hasDataInd;
	}
	
	public void setHasDataInd(boolean hasDataInd) {
		this.hasDataInd = hasDataInd;
	}
	
	public String getPdfUrl() {
		return pdfUrl;
	}
	
	public void setPdfUrl(String pdfUrl) {
		this.pdfUrl = pdfUrl;
	}
	
	public InvcHdr getReverseInvoice(){
		InvcHdr rverseInvc=new InvcHdr();
		
		rverseInvc.setOrder_key(this.order_key);
		rverseInvc.setCust_key(this.cust_key);
		rverseInvc.setCustTel(this.custTel);
		rverseInvc.setCust_name(this.cust_name);
		rverseInvc.setCss_tax_id(this.css_tax_id);
		rverseInvc.setCss_bank_ac(this.css_bank_ac);
		rverseInvc.setCss_address(this.css_address);
		rverseInvc.setInvc_type(this.invc_type);
		rverseInvc.setRemark(this.remark);
		rverseInvc.setStat_cde(InvcHdr.STAT_CDE_I);
		rverseInvc.setCreate_user(this.create_user);
		rverseInvc.setAnd_red_id(this.id);
		rverseInvc.setOrigWhInvcId(this.wh_invc_id);
		rverseInvc.setOrigWhInvcNbr(this.wh_invc_nbr);
		
		rverseInvc.setOrigInvcDte(this.update_dte);//L40005_8 li.pei.jie
		
		rverseInvc.setTaxNoteMethd(this.taxNoteMethd);
		
		ArrayList<InvcDetail> tempInvcDetailList=new ArrayList<InvcDetail>();
		
		
		for(InvcDetail invcDetail:InvcDetailList){
			InvcDetail tempInvcDetail=new InvcDetail();
			
			tempInvcDetail.setProduct_desc(invcDetail.getProduct_desc());
			tempInvcDetail.setUsage_desc(invcDetail.getUsage_desc());
			tempInvcDetail.setQty_unit(invcDetail.getQty_unit());	
			tempInvcDetail.setQty(-1*invcDetail.getQty());
			tempInvcDetail.setAmt(-1*invcDetail.getAmt());
			tempInvcDetail.setItem_nbr(invcDetail.getItem_nbr());
			tempInvcDetail.setOrder_key(invcDetail.getOrder_key());
			tempInvcDetail.setOrder_line_nbr(invcDetail.getOrder_line_nbr());
			tempInvcDetail.setWeight(-1*invcDetail.getWeight());
			tempInvcDetail.setWeight_unit(invcDetail.getWeight_unit());
			tempInvcDetail.setSeq_nbr(invcDetail.getSeq_nbr());
			tempInvcDetail.setSelectInd(true);
			tempInvcDetail.setProdType(invcDetail.getProdType()); //L46242_1 zhong.hai.hao
			tempInvcDetail.setOrderDate(invcDetail.getOrderDate()); //L46242_1 zhong.hai.hao
			tempInvcDetail.setTaxPct(invcDetail.getTaxPct());//L49603_1 zhou.ren.kuan
			tempInvcDetailList.add(tempInvcDetail);
		}
		
		rverseInvc.setInvcDetailList(tempInvcDetailList);
		return rverseInvc;
	}
	
	public static final String STAT_CDE_I="I";
	
	public static final String STAT_CDE_A="A";
	
	public static final String STAT_CDE_S="S";
	
	public static final String STAT_CDE_E="E";
	
	public static final String STAT_CDE_C="C";
	
	public static final String TAX_NOTE_METHD_E="E";

	public static final String TAX_NOTE_METHD_P="P";
	
	public boolean checkInvcInfoIsSame(InvcHdr invc){
		if(invc==null || this.cust_name==null || invc.getCust_name()==null || !this.cust_name.equals(invc.getCust_name())
				|| this.custTel==null || invc.getCustTel()==null || !this.custTel.equals(invc.getCustTel())
				|| this.InvcDetailList==null || invc.getInvcDetailList()==null 
				|| this.InvcDetailList.size()!= invc.getInvcDetailList().size()){
			return false;
		}
		
		ArrayList<InvcDetail> tempInvcDetails=invc.getInvcDetailList(); 
		
		for(InvcDetail thisInvcDetail:InvcDetailList){
			int thisLineNbr = thisInvcDetail.getOrder_line_nbr();
			double thisAmt = thisInvcDetail.getAmt();
			for(InvcDetail tempInvcDetail:tempInvcDetails){
				if(thisLineNbr==tempInvcDetail.getOrder_line_nbr() && thisAmt != tempInvcDetail.getAmt()){
					return false;
				}
			}
		}
		
		return true;
	}
	//L40005_1 li.pei.jie end
	
	//L40005_8 li.pei.jie start
	public String getInvcItemNbrs(){
		String itemNbrs="";
		if(InvcDetailList!=null && InvcDetailList.size()>0){
			for(InvcDetail invcDetail:InvcDetailList){
				if(invcDetail.isSelectInd()){	
					itemNbrs=itemNbrs+invcDetail.getItem_nbr()+",";
				}
			}
		}
		
		if(itemNbrs.length()>1){
			itemNbrs=itemNbrs.substring(0,itemNbrs.length()-1);
		}
		
		return itemNbrs;
	} 
	
	private Date origInvcDte;

	public Date getOrigInvcDte() {
		return origInvcDte;
	}
	
	public void setOrigInvcDte(Date origInvcDte) {
		this.origInvcDte = origInvcDte;
	}
	
	public String getOrigInvcDteDesc(){
		if(origInvcDte!=null){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			return sdf.format(origInvcDte);
		}
		return "";
	}
	//L40005_8 li.pei.jie end
	
	//L54280_1 huang.hui start
	private boolean select_ind;

	public boolean isSelect_ind() {
		return select_ind;
	}
	public void setSelect_ind(boolean select_ind) {
		this.select_ind = select_ind;
	}
	
	//L54280_1 huang.hui end
}
